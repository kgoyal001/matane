import requests
import time
from colorama import Fore, Style, init
import json
from datetime import datetime, timedelta, timezone
import random
import urllib.parse
import base64

headers = {
    'accept': 'application/json, text/plain, */*',
    'accept-language': 'en,en-US;q=0.9',
    'cache-control': 'no-cache',
    'content-type': 'application/json',
    'origin': 'https://mini-app.tomarket.ai',
    'pragma': 'no-cache',
    'priority': 'u=1, i',
    'referer': 'https://mini-app.tomarket.ai/',
    'sec-ch-ua': '"Not/A)Brand";v="8", "Chromium";v="126", "Android WebView";v="126"',
    'sec-ch-ua-mobile': '?1',
    'sec-ch-ua-platform': 'Android',
    'sec-fetch-dest': 'empty',
    'sec-fetch-mode': 'cors',
    'sec-fetch-site': 'same-site',
    'user-agent': 'Mozilla/5.0 (Linux; Android 13; M2012K11AG Build/TKQ1.220829.002; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/126.0.6478.134 Mobile Safari/537.36',
    'x-requested-with': 'org.telegram.messenger.web'
}

 

def load_proxies():
    proxies = []
    try:
        with open('proxy.txt', 'r') as proxy_file:
            proxies = proxy_file.readlines()
    except FileNotFoundError:
        print("Proxy file not found.")
    return [proxy.strip() for proxy in proxies]

proxies = load_proxies()

  
 

def get_proxy():
    if proxies:
        proxy = random.choice(proxies)
        user_pass, ip_port = proxy.split('@')
        proxy_username, proxy_password = user_pass.split(':')
        proxy_auth = f"{proxy_username}:{proxy_password}"
        
        return {
            "http": f"http://{proxy_auth}@{ip_port}",
            "https": f"http://{proxy_auth}@{ip_port}",  # Use HTTP for both
        }
    return None


def get_task_list(token):
    url = 'https://api-web.tomarket.ai/tomarket-game/v1/tasks/list'
    headers['Authorization'] = token
    proxy = get_proxy()
    try:
        response = requests.post(url, headers=headers, json={"language_code": "en"}, proxies=proxy)
        response.raise_for_status()
        return response.json()
    except json.JSONDecodeError:
        print(f"JSON Decode Error: Token Invalid")
        return None
    except requests.RequestException as e:
        print(f"Request Error: {e}")
        return None

def start_task(token, task_id):
    url = 'https://api-web.tomarket.ai/tomarket-game/v1/tasks/start'
    headers['Authorization'] = token
    proxy = get_proxy()
    try:
        response = requests.post(url, headers=headers, json={"task_id": task_id}, proxies=proxy)
        response.raise_for_status()
        return response.json()
    except json.JSONDecodeError:
        print(f"JSON Decode Error: Token Invalid")
        return None
    except requests.RequestException as e:
        print(f"Request Error: {e}")
        return None

def check_task(token, task_id):
    url = 'https://api-web.tomarket.ai/tomarket-game/v1/tasks/check'
    headers['Authorization'] = token
    proxy = get_proxy()
    try:
        response = requests.post(url, headers=headers, json={"task_id": task_id}, proxies=proxy)
        response.raise_for_status()
        return response.json()
    except json.JSONDecodeError:
        print(f"JSON Decode Error: Token Invalid")
        return None
    except requests.RequestException as e:
        print(f"Request Error: {e}")
        return None

def claim_task(token, task_id):
    url = 'https://api-web.tomarket.ai/tomarket-game/v1/tasks/claim'
    headers['Authorization'] = token
    proxy = get_proxy()
    try:
        response = requests.post(url, headers=headers, json={"task_id": task_id}, proxies=proxy)
        response.raise_for_status()
        return response.json()
    except json.JSONDecodeError:
        print(f"JSON Decode Error: Token Invalid")
        return None
    except requests.RequestException as e:
        print(f"Request Error: {e}")
        return None

def handle_tasks(token):
    task_list = get_task_list(token)
    if not task_list:
        return

    task_categories = ['standard', 'default', 'special', 'expired']
    for category in task_categories:
        if category in task_list['data']:
            print(f"{Fore.YELLOW}[ Tasks ]: List Task {category.capitalize()} {Style.RESET_ALL}", flush=True)
            for task in task_list['data'][category]:
                if task['taskId'] == 206000 or task['name'] == "invite task":
                    continue
                print(f"{Fore.YELLOW+Style.BRIGHT}          -> {task['name']} Starting                              {Style.RESET_ALL}",  flush=True)
                while True:
                    time.sleep(2)
                    start_response = start_task(token, task['taskId'])
                    # print(start_response)
                    if start_response and start_response['message'] == 'claim throttle':
                        print(f"{Fore.RED+Style.BRIGHT}          -> {task['name']} Too Fast Starting      {Style.RESET_ALL}" ,flush=True)
                        time.sleep(5)
                    else:
                        break
                        
                if start_response and start_response.get('status') == 0:
                    if start_response['data']['status'] == 3:
                        print(f"{Fore.GREEN+Style.BRIGHT}          -> {task['name']} Completed                  {Style.RESET_ALL}", flush=True)
                        time.sleep(3)
                    elif start_response['data']['status'] == 1:
                        print(f"{Fore.YELLOW+Style.BRIGHT}          -> {task['name']} Started                {Style.RESET_ALL}", flush=True)
                        time.sleep(3)
                        for _ in range(10):
                            time.sleep(3)
                            check_response = check_task(token, task['taskId'])
                            if check_response and 'status' in check_response['data'] and check_response['data']['status'] == 2:
                                print(f"{Fore.CYAN+Style.BRIGHT}          -> {task['name']} Finished                  {Style.RESET_ALL}" , flush=True)
                                claim_response = claim_task(token, task['taskId'])
                                if claim_response and claim_response['status'] == 0:
                                    print(f"{Fore.GREEN+Style.BRIGHT}          -> {task['name']} Claimed                {Style.RESET_ALL}", flush=True)
                                break
                            elif check_response and 'status' in check_response['data'] and check_response['data']['status'] == 1:
                                print(f"{Fore.YELLOW+Style.BRIGHT}          -> {task['name']} Checking                     {Style.RESET_ALL}",  flush=True)
                                time.sleep(3)
                            else:
                                print(f"{Fore.RED+Style.BRIGHT}          -> {task['name']} Too Fast Checking            {Style.RESET_ALL}",   flush=True)
                                time.sleep(5)
                    else:
                        print(f"{Fore.RED+Style.BRIGHT}          -> {task['name']} Too Fast Checking             {Style.RESET_ALL}",  flush=True)
                elif start_response and start_response.get('status') == 3:
                    print(f"{Fore.GREEN+Style.BRIGHT}          -> {task['name']} Claimed                {Style.RESET_ALL}", flush=True)
                elif start_response and start_response.get('status') == 2:
                    print(f"{Fore.GREEN+Style.BRIGHT}          -> {task['name']} Started                {Style.RESET_ALL}",  flush=True)
                    time.sleep(3)
                    for _ in range(10):
                        time.sleep(3)
                        check_response = check_task(token, task['taskId'])
                        if check_response and 'status' in check_response['data'] and check_response['data']['status'] == 2:
                            print(f"{Fore.CYAN+Style.BRIGHT}          -> {task['name']} Finished                  {Style.RESET_ALL}" , flush=True)
                            claim_response = claim_task(token, task['taskId'])
                            if claim_response and claim_response['status'] == 0:
                                print(f"{Fore.GREEN+Style.BRIGHT}          -> {task['name']} Claimed                {Style.RESET_ALL}", flush=True)
                            break
                        elif check_response and 'status' in check_response['data'] and check_response['data']['status'] == 1:
                            print(f"{Fore.YELLOW+Style.BRIGHT}          -> {task['name']} Checking                     {Style.RESET_ALL}",  flush=True)
                            time.sleep(3)
                        else:
                            print(f"{Fore.RED+Style.BRIGHT}          -> {task['name']} Too Fast Checking            {Style.RESET_ALL}", end="\r", flush=True)
                            time.sleep(5)
                
                    

def get_access_token(query_data):
    url = 'https://api-web.tomarket.ai/tomarket-game/v1/user/login'
    proxy = get_proxy()
    try:
        data = json.dumps(
            {
                "init_data": query_data,
                "invite_code": "",
            })
        response = requests.post(url, headers=headers, data=data, proxies=proxy)
        response.raise_for_status() 
        # print(response.json())
        return response.json(), response.status_code
    except json.JSONDecodeError:
        print(f"JSON Decode Error: Query Anda Salah")
        return None
    except requests.RequestException as e:
        print(f"Request Error: {e}")
        return None

def get_balance(token):
    url = 'https://api-web.tomarket.ai/tomarket-game/v1/user/balance'
    headers['Authorization'] = token
    proxy = get_proxy()
    try:
        response = requests.post(url, headers=headers, proxies=proxy)
        response.raise_for_status()
        return response.json()
    except json.JSONDecodeError:
        print(f"JSON Decode Error: Token Invalid")
        return None
    except requests.RequestException as e:
        print(f"Request Error: {e}")
        return None

def get_task_id(token):
    url = 'https://api-web.tomarket.ai/tomarket-game/v1/tasks/hidden'
    headers['Authorization'] = token
    proxy = get_proxy()
    try:
        response = requests.post(url, headers=headers, proxies=proxy)
        response.raise_for_status()
        task_data = response.json()
        if task_data['status'] == 0 and task_data['data']:
            return task_data['data'][0]['taskId']
        else:
            print(f"Failed to get task ID: {task_data}")
            return None
    except json.JSONDecodeError:
        print(f"JSON Decode Error: Token Invalid")
        return None
    except requests.RequestException as e:
        print(f"Request Error: {e}")
        return None

def ghalibie_gacor(token):
    task_id = get_task_id(token)
    if not task_id:
        print("No valid task ID found.")
        return None

    url = 'https://api-web.tomarket.ai/tomarket-game/v1/tasks/hidden'
    headers['Authorization'] = token
    # payload = {"task_id": task_id}
    proxy = get_proxy()
    try:
        response = requests.post(url, headers=headers, proxies=proxy)
        response.raise_for_status()
        return response.json()
    except json.JSONDecodeError:
        print(f"JSON Decode Error: Token Invalid")
        return None
    except requests.RequestException as e:
        print(f"Request Error: {e}")
        return None
    
def claim_daily(token):
    url = 'https://api-web.tomarket.ai/tomarket-game/v1/daily/claim'
    headers['Authorization'] = token
    payload = {"game_id": "fa873d13-d831-4d6f-8aee-9cff7a1d0db1"}
    proxy = get_proxy()

    try:
        response = requests.post(url, headers=headers, json=payload, proxies=proxy)
        response.raise_for_status()
        return response.json(), response.status_code
    except json.JSONDecodeError:
        print(f"JSON Decode Error: Token Invalid")
        return None, None
    except requests.RequestException as e:
        print(f"Request Error: {e}")
        return None, None

def start_farming(token):
    url = 'https://api-web.tomarket.ai/tomarket-game/v1/farm/start'
    headers['Authorization'] = token
    payload = {"game_id": "53b22103-c7ff-413d-bc63-20f6fb806a07"}
    proxy = get_proxy()
    try:
        response = requests.post(url, headers=headers, json=payload, proxies=proxy)
        response.raise_for_status()
        return response.json(), response.status_code
    except json.JSONDecodeError:
        print(f"JSON Decode Error: Token Invalid")
        return None, None
    except requests.RequestException as e:
        print(f"Request Error: {e}")
        return None, None
    
def claim_farming(token):
    url = 'https://api-web.tomarket.ai/tomarket-game/v1/farm/claim'
    headers['Authorization'] = token
    payload = {"game_id": "53b22103-c7ff-413d-bc63-20f6fb806a07"}
    proxy = get_proxy()
    try:
        response = requests.post(url, headers=headers, json=payload, proxies=proxy)
        response.raise_for_status()
        return response.json(), response.status_code
    except json.JSONDecodeError:
        print(f"JSON Decode Error: Token Invalid")
        return None, None
    except requests.RequestException as e:
        print(f"Request Error: {e}")
        return None, None

def play_game(token):
    url = 'https://api-web.tomarket.ai/tomarket-game/v1/game/play'
    headers['Authorization'] = token
    payload = {"game_id": "59bcd12e-04e2-404c-a172-311a0084587d"}
    proxy = get_proxy()
    try:
        response = requests.post(url, headers=headers, json=payload, proxies=proxy)
        response.raise_for_status()
        return response.json(), response.status_code
    except json.JSONDecodeError:
        print(f"JSON Decode Error: Token Invalid")
        return None, None
    except requests.RequestException as e:
        print(f"Request Error: {e}")
        return None, None

def claim_game(token, point):
    url = 'https://api-web.tomarket.ai/tomarket-game/v1/game/claim'
    headers['Authorization'] = token
    payload = {"game_id": "59bcd12e-04e2-404c-a172-311a0084587d", "points": point}
    proxy = get_proxy()
    try:
        response = requests.post(url, headers=headers, json=payload, proxies=proxy)
        response.raise_for_status()
        return response.json(), response.status_code
    except json.JSONDecodeError:
        print(f"JSON Decode Error: Token Invalid")
        return None, None
    except requests.RequestException as e:
        print(f"Request Error: {e}")
        return None, None
def connect_wallet(token, wallet_address):
    url = "https://api-web.tomarket.ai/tomarket-game/v1/tasks/address"
    payload = json.dumps({"wallet_address": wallet_address})
    headers['Authorization'] = token
    proxy = get_proxy()
    
    try:
        response = requests.post(url, headers=headers, data=payload, proxies=proxy)
        response.raise_for_status()
        result = response.json()
        
        if result['status'] == 0:
            print(f"{Fore.GREEN+Style.BRIGHT}[ Wallet ]: Success Bind {wallet_address} {Style.RESET_ALL}", flush=True)
            return True
        elif result['message'] == "Verification failed, Ton address has been used by other user":
            print(f"{Fore.RED+Style.BRIGHT}[ Wallet ]: Address {wallet_address} Already Linked {Style.RESET_ALL}", flush=True)
        elif result['message'] == "Verification failed, Already have a wallet address":
            print(f"{Fore.GREEN+Style.BRIGHT}[ Wallet ]: Already Linked {Style.RESET_ALL}", flush=True)
            return True
        elif result['message'] == "Verification failed, Ton address is not from Bitget Wallet":
            print(f"{Fore.RED+Style.BRIGHT}[ Wallet ]: Address {wallet_address} Not From Bidget {Style.RESET_ALL}", flush=True)
    except json.JSONDecodeError:
        print("JSON Decode Error: Token Invalid")
    except requests.RequestException as e:
        print(f"Request Error: {e}")
    
    return False

def load_wallets():
    wallets = []
    try:
        with open('wallet.txt', 'r') as wallet_file:
            wallets = wallet_file.readlines()
    except FileNotFoundError:
        print("Wallet file not found.")
    return [wallet.strip() for wallet in wallets]

wallets = load_wallets()

def main():
    tokens = []
    try:
        with open('tokens.txt', 'r') as token_file:
            tokens = token_file.readlines()
    except FileNotFoundError:
        pass
    connect = input('Auto Connect Wallet? (Y/N): ').strip().upper()
    clear_tasks = input('Auto Clear Task? (Y/N): ').strip().upper()
    play_game_option = input('Play Game? (Y/N): ').strip().upper()
    
    total_balance = 0
    while True:
        print_welcome_message()
        for i, token in enumerate(tokens):
            token = token.strip()
            print(f"{Fore.YELLOW+Style.BRIGHT}Checking account..", end="\r", flush=True)
            
            # Replace firstname and lastname with "akun ke {index} token"
            firstname = f"akun ke {i+1}"
            lastname = " Generous Member"
            print(Fore.CYAN + Style.BRIGHT + f"===== [ Akun {i+1} - {firstname} ] {lastname}  =====             ", flush=True)
            
            print(f"{Fore.YELLOW+Style.BRIGHT}Getting balance..", end="\r", flush=True)
            proxy = get_proxy()
            if proxy:
                print(f"{Fore.GREEN+Style.BRIGHT}[ Proxy ]: {proxy['http']} {Style.RESET_ALL}", flush=True)
            else:
                print(f"{Fore.GREEN+Style.BRIGHT}[ Proxy ]: No Proxy {Style.RESET_ALL}          ", flush=True)
            balance_response = get_balance(token)
            if balance_response is not None:
                balance = float(balance_response['data'].get('available_balance'))
                total_balance += balance
                balance = f"{balance:,.0f}".replace(",", ".")  # Format balance with dots as thousand separators
                tiket = balance_response['data'].get('play_passes')
                print(f"{Fore.GREEN+Style.BRIGHT}[ Balance ]: {balance} {Style.RESET_ALL}           ", flush=True)
                print(f"{Fore.GREEN+Style.BRIGHT}[ Tiket ]: {tiket} {Style.RESET_ALL}           ", flush=True)
                # print(f"{Fore.YELLOW+Style.BRIGHT}[ Combo ]: Claiming.. {Style.RESET_ALL}", end="\r" ,flush=True)
                # time.sleep(2)
                # combo = ghalibie_gacor(token)
                # if combo['status'] == 0:
                #     print(f"{Fore.GREEN+Style.BRIGHT}[ Combo ]: Claimed!         {Style.RESET_ALL}", flush=True)
                # else:
                #     print(f"{Fore.RED+Style.BRIGHT}[ Combo ]: Failed to claim. {combo} {Style.RESET_ALL}", flush=True)
                print(f"{Fore.YELLOW+Style.BRIGHT}[ Daily ]: Claiming.. {Style.RESET_ALL}", end="\r" ,flush=True)
                time.sleep(2)
                daily, daily_status_code = claim_daily(token)
                if daily_status_code == 400:
                    if daily['message'] == 'already_check':
                        day = daily['data']['check_counter']
                        point = daily['data']['today_points']
                        print(f"{Fore.GREEN+Style.BRIGHT}[ Daily ]: Day {day} Already checkin | {point} Point{Style.RESET_ALL}", flush=True)
                    else:
                        print(f"{Fore.RED+Style.BRIGHT}[ Daily ]: Gagal {daily} {Style.RESET_ALL}", flush=True)
                elif daily_status_code == 200:
                    day = daily['data']['check_counter']
                    point = daily['data']['today_points']
                    print(f"{Fore.GREEN+Style.BRIGHT}[ Daily ]: Day {day} Claimed | {point} Point{Style.RESET_ALL}", flush=True)
                    
                    
                else:
                    print(f"{Fore.RED+Style.BRIGHT}[ Daily ]: Gagal {daily} {Style.RESET_ALL}", flush=True)

                if clear_tasks == 'Y':
                    # print(f"{Fore.YELLOW}[ Tasks ]: List Task {Style.RESET_ALL}", flush=True)
            
                    handle_tasks(token)
                # Connect wallet after claiming daily
                if connect == 'Y':
                    while wallets:
                        print(f"{Fore.YELLOW+Style.BRIGHT}[ Wallet ]: Checking.. {Style.RESET_ALL}", end="\r", flush=True)
                        time.sleep(1)
                        wallet_address = wallets.pop(0)
                        if connect_wallet(token, wallet_address):
                            with open('wallet.txt', 'w') as wallet_file:
                                wallet_file.write('\n'.join(wallets))
                            break
                print(f"{Fore.YELLOW+Style.BRIGHT}[ Farming ]: Checking.. {Style.RESET_ALL}", end="\r", flush=True)
                time.sleep(2)
                farming, farming_status_code = start_farming(token)
                if farming_status_code == 200:
                    end_time = datetime.fromtimestamp(farming['data']['end_at'])
                    remaining_time = end_time - datetime.now()
                    hours, remainder = divmod(remaining_time.total_seconds(), 3600)
                    minutes, _ = divmod(remainder, 60)
                    print(f"{Fore.GREEN+Style.BRIGHT}[ Farming ]: Started. Claim in: {int(hours)} jam {int(minutes)} menit {Style.RESET_ALL}", flush=True)
                    if datetime.now() > end_time:
                            print(f"{Fore.YELLOW+Style.BRIGHT}[ Farming ]: Claiming.. {Style.RESET_ALL}", end="\r", flush=True)
                            claim_response, claim_status_code = claim_farming(token)
                            if claim_status_code == 200:
                                poin = claim_response["data"]["claim_this_time"]
                                print(f"{Fore.GREEN+Style.BRIGHT}[ Farming ]: Success Claim Farming! Reward: {poin} {Style.RESET_ALL}       ", flush=True)
                                print(f"{Fore.YELLOW+Style.BRIGHT}[ Farming ]: Starting.. {Style.RESET_ALL}", end="\r", flush=True)
                                time.sleep(2)
                                farming, farming_status_code = start_farming(token)
                                if farming_status_code == 200:
                                    end_time = datetime.fromtimestamp(farming['data']['end_at'])
                                    remaining_time = end_time - datetime.now()
                                    hours, remainder = divmod(remaining_time.total_seconds(), 3600)
                                    minutes, _ = divmod(remainder, 60)
                                    print(f"{Fore.GREEN+Style.BRIGHT}[ Farming ]: Started. Claim in: {int(hours)} jam {int(minutes)} menit {Style.RESET_ALL}", flush=True)

                            else:
                                print(f"{Fore.RED+Style.BRIGHT}Failed to claim farming: {claim_response} {Style.RESET_ALL}          ", flush=True)
                elif farming_status_code == 500:
                    if farming['message'] == 'game already started':
                        end_time = datetime.fromtimestamp(farming['data']['end_at'])
                        remaining_time = end_time - datetime.now()
                        hours, remainder = divmod(remaining_time.total_seconds(), 3600)
                        minutes, _ = divmod(remainder, 60)
                        print(f"{Fore.CYAN+Style.BRIGHT}[ Farming ]: Already Started. Claim in: {int(hours)} jam {int(minutes)} menit {Style.RESET_ALL}", flush=True)
                        
                        # Check if current time is past end_time
                        if datetime.now() > end_time:
                            print(f"{Fore.YELLOW+Style.BRIGHT}[ Farming ]: Claiming.. {Style.RESET_ALL}", end="\r", flush=True)
                            claim_response, claim_status_code = claim_farming(token)
                            if claim_status_code == 200:
                                poin = claim_response["data"]["claim_this_time"]
                                print(f"{Fore.GREEN+Style.BRIGHT}Success claim farming! Reward: {poin} {Style.RESET_ALL}", flush=True)
                                print(f"{Fore.YELLOW+Style.BRIGHT}[ Farming ]: Starting.. {Style.RESET_ALL}", end="\r", flush=True)
                                time.sleep(2)
                                farming, farming_status_code = start_farming(token)
                                if farming_status_code == 200:
                                    end_time = datetime.fromtimestamp(farming['data']['end_at'])
                                    remaining_time = end_time - datetime.now()
                                    hours, remainder = divmod(remaining_time.total_seconds(), 3600)
                                    minutes, _ = divmod(remainder, 60)
                                    print(f"{Fore.GREEN+Style.BRIGHT}[ Farming ]: Started. Claim in: {int(hours)} jam {int(minutes)} menit {Style.RESET_ALL}", flush=True)


                            else:
                                print(f"{Fore.RED+Style.BRIGHT}Failed to claim farming: {claim_response} {Style.RESET_ALL}", flush=True)
                    else:
                        print(f"{Fore.GREEN+Style.BRIGHT}[ Farming ]: Error. {farming} {Style.RESET_ALL}", flush=True)
                else:
                    print(f"{Fore.GREEN+Style.BRIGHT}[ Farming ]: Error {farming} {Style.RESET_ALL}", flush=True)
                
                if play_game_option == 'Y':
                    while tiket > 0:
                        print(f"{Fore.GREEN+Style.BRIGHT}[ Game ]: Starting Game..", end="\r", flush=True)
                        play, play_status = play_game(token)
                        if play_status != 200:
                            print(f"{Fore.RED+Style.BRIGHT}[ Game ]: Failed to start game!       {Style.RESET_ALL}", flush=True)
                        else:
                            print(f"{Fore.GREEN+Style.BRIGHT}[ Game ]: Game Started! {Style.RESET_ALL}                      ", flush=True)
                            for _ in range(30):
                                print(f"{random.choice([Fore.RED, Fore.GREEN, Fore.YELLOW, Fore.BLUE, Fore.MAGENTA, Fore.CYAN, Fore.WHITE])+Style.BRIGHT}[ Game ]: Playing game, waktu sisa {30 - _} detik {Style.RESET_ALL}", end="\r", flush=True)
                                time.sleep(1)
                            print(f"{Fore.YELLOW+Style.BRIGHT}[ Game ]: Game Berakhir! Claiming..                                       ", end="\r", flush=True)
                            point = random.randint(400, 600)
                            claim, claim_status = claim_game(token, point)
                            if claim_status != 200:
                                print(f"{Fore.RED+Style.BRIGHT}[ Game ]: Failed to claim game points! {Style.RESET_ALL}", flush=True)
                            else:
                                print(f"{Fore.GREEN+Style.BRIGHT}[ Game ]: Success. Mendapatkan {point} Poin {Style.RESET_ALL}                    ", flush=True)

                            tiket -= 1
        print(Fore.GREEN + Style.BRIGHT + f"Total Balance: {total_balance:,.0f}".replace(",", ".") + f" {Style.RESET_ALL}", flush=True)  # Display total balance
        print(Fore.BLUE + Style.BRIGHT + f"\n==========SEMUA AKUN TELAH DI PROSES==========\n",  flush=True)    
        for _ in range(1800):
            minutes, seconds = divmod(1800 - _, 60)
            print(f"{random.choice([Fore.RED, Fore.GREEN, Fore.YELLOW, Fore.BLUE, Fore.MAGENTA, Fore.CYAN, Fore.WHITE])+Style.BRIGHT}==== [ Semua akun telah diproses, Looping berikutnya {minutes} menit {seconds} detik ] ===={Style.RESET_ALL}", end="\r", flush=True)
            time.sleep(1)         
             
       

from datetime import datetime, timedelta, timezone
start_time = datetime.now()
def print_welcome_message():
    print(Fore.WHITE + r"""
          
🆂🅸🆁🅺🅴🅻
          
█▀▀ █▀▀ █▄░█ █▀▀ █▀█ █▀█ █░█ █▀
█▄█ ██▄ █░▀█ ██▄ █▀▄ █▄█ █▄█ ▄█
          """)
    print(Fore.GREEN + Style.BRIGHT + "Tomarket BOT")
    print(Fore.BLUE + Style.BRIGHT + "Buy me a coffee :) 0823 2367 3487 GOPAY / DANA")
    print(Fore.RED + Style.BRIGHT + "NOT FOR SALE ! Ngotak dikit bang. Ngoding susah2 kau tinggal rename :)\n")
    current_time = datetime.now()
    up_time = current_time - start_time
    days, remainder = divmod(up_time.total_seconds(), 86400)
    hours, remainder = divmod(remainder, 3600)
    minutes, seconds = divmod(remainder, 60)
    print(Fore.CYAN + Style.BRIGHT + f"Up time bot: {int(days)} hari, {int(hours)} jam, {int(minutes)} menit, {int(seconds)} detik\n\n")

if __name__ == "__main__":
    main()