
# Tomarket Bot 
Tomarket BOT

Register Here : [Tomarket](https://t.me/Tomarket_ai_bot/app?startapp=00000loQ)

Free 2.000 Point

## Features
    - Auto Checkin
    - Auto Claim
    - Auto Farming
    - Auto Playing Game
    - Auto Get token
    - Multi Account

## Installation

Install with python

    1. Download Python 3.10+
    2. Install Module (pip install requests colorama)
    3. Buka Bot Tomarket di PC (Telegram Web / Desktop)
    4. Jika sudah terbuka > Klik kanan Inspect
    5. Ke Console > ambil init data raw
    6. Paste di query.txt
    8. python tomarket.py

 

![SS](https://i.ibb.co.com/KG3CM3N/Cuplikan-layar-2024-07-07-021936.png)